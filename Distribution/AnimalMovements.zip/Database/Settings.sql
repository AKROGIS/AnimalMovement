USE [Animal_Movement]
GO
INSERT [dbo].[Settings] ([Username], [Key], [Value]) VALUES (N'system', N'version', N'2.0')
INSERT [dbo].[Settings] ([Username], [Key], [Value]) VALUES (N'system', N'dba_contact', N'Regan Sarwas at 644-3548 or regan_sarwas@nps.gov')
INSERT [dbo].[Settings] ([Username], [Key], [Value]) VALUES (N'system', N'argosProcessor', N'C:\Documents and Settings\sql_proxy\ArgosProcessor.exe')
INSERT [dbo].[Settings] ([Username], [Key], [Value]) VALUES (N'system', N'sa_email', N'nps.animal.movements@gmail.com')
INSERT [dbo].[Settings] ([Username], [Key], [Value]) VALUES (N'system', N'sa_email_password', N'xxxxx')
